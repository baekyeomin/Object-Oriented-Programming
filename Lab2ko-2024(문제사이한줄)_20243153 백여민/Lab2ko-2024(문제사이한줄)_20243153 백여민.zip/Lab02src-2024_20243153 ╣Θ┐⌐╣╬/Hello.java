// ********************************************
// Hello.java
//
// Print a Hello, World message.
// ********************************************
public class Hello
{
    // -----------------------------------
    // main method -- prints the greeting
    // -----------------------------------
    public static void main(String[] args)
    {
        System.out.println("Hello, World!");
    }
}
