//20243153 백여민
public class Useless {
	// Prints some simple messages.
	public static void main(String[] args) {
	System.out.print("   Some useless facts");
	System.out.println("");
	System.out.println("   Your ears never stop growing");
	System.out.println("   Catsup travels at" + (100/4) + "miles per year");
	System.out.println("SimpleName");
	} // method main
	
}
