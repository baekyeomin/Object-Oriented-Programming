/**
 * A test class for PPoint.
 * @author 백여민
 * @version 1.0
 */
public class PPointTest {
    public static void main(String[] args) {
        PPoint point = new PPoint(10, 20);
        System.out.println("Point: (" + point.getX() + ", " + point.getY() + ")");
    }
}
