public class NumberVariablesTester
{
	public static void main(String[] args) {
		double n1 = 150;
		double n2 = n1;
		n2 = n2 * 20; // grow n2
		System.out.println(n1);
		System.out.println(n2);
		}
}