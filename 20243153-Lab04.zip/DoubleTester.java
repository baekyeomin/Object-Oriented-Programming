public class DoubleTester {
    public static void main(String[] args) {
        double probability = 8.70;
        int percentage = (int) Math.round(100 * probability); 
        System.out.println(percentage);
    }
}
